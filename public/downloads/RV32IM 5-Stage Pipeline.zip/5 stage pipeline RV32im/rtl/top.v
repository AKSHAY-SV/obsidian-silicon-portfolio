module top (
    input  wire        clk,
    input  wire        rst,
    output wire [31:0] pc_out,      // PC
    output wire [31:0] alu_result,  // ALU output
    output wire [31:0] instr,       // Current instruction
    output wire        reg_write    // Control signal
);
    datapath u_datapath (
        .clk(clk),
        .rst(rst),
        .pc_out(pc_out),
        .alu_result(alu_result),
        .instr(instr),
        .reg_write(reg_write)
    );
endmodule
