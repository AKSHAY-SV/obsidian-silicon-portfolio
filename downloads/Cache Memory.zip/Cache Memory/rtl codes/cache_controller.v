`timescale 1ns / 1ps

module cache_controller(
input wire clk,
input wire rst,
input wire hit,

output reg cache_we,
output reg mem_we,

output reg [2:0] state //3 bit state

);
parameter IDLE   = 3'b000;//State:0 IDLE
parameter CHECK  = 3'b001;//State:1 CHECK
parameter HIT    = 3'b010;//State:1 HIT
parameter MISS   = 3'b011;//State:2 MISS 
parameter REFILL = 3'b100;//State:3 REFILL
always @(posedge clk or posedge rst) begin
if(rst)
state <= IDLE;
else begin
case(state)

    IDLE:
    state <= CHECK;

    CHECK:

     if(hit)
        state <= HIT;
           else
        state <= MISS;

     HIT:
        state <= CHECK;
     MISS:
         state <= REFILL;

     REFILL:
         state <= CHECK;

      default:
         state <= IDLE;

            endcase

        end

    end
always @(*) begin

 cache_we = 0;
 mem_we   = 0;
 case(state)
       HIT: begin

  cache_we = 0;
  mem_we   = 0;

     end

        MISS: begin

   cache_we = 1;
   mem_we   = 0;

     end

 REFILL: begin

   cache_we = 1;
   mem_we   = 0;

end

        endcase

    end

endmodule
