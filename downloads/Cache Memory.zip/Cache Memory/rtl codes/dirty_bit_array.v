`timescale 1ns / 1ps

module dirty_bit_array(

    input wire clk,
    input wire we,
    input wire [1:0] addr,
    input wire dirty_in,
    output wire dirty_out //wire because it is no used in always block else must be used with reg

);
reg dirty_mem [0:3];
always @(posedge clk) begin
if(we)

            dirty_mem[addr] <= dirty_in;
                                            
    end

    assign dirty_out = dirty_mem[addr];

endmodule
