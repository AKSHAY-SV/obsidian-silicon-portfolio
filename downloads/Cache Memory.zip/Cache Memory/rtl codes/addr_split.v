`timescale 1ns / 1ps
module addr_split(
input wire [4:0]cpu_addr,
output wire [2:0]tag,
output wire [1:0]index
);
assign tag=cpu_addr[4:2];
assign index=cpu_addr[1:0];
endmodule
