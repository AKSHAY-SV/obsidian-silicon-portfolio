`timescale 1ns / 1ps
module cache_top(
input wire clk,
input wire cs,
input wire we,
input wire [4:0] cpu_address,

input wire [3:0] data_in,

input wire valid_in,
    
output wire [3:0] data_out,
output wire hit

);
wire [2:0] tag;
wire [1:0] index;
wire [2:0] stored_tag;
wire valid_out;
wire [3:0] data_sram_out;
wire tag_match_valid;

addr_split addr_split_inst(
    .cpu_addr(cpu_address),
    .tag(tag),
    .index(index)
);

sram_module data_sram_inst(
    .clk(clk),
    .cs(cs),
    .we(we),
    .addr(index),
    .din(data_in),
    .dout(data_sram_out)
);

tag_sram_4x3 tag_sram_inst(
    .clk(clk),
    .cs(cs),
    .we(we),
    .addr(index),
    .din(tag),
    .dout(stored_tag)
);

valid_bit_array valid_array_inst(
    .clk(clk),
    .cs(cs),
    .wl(we),
    .addr(index),
    .valid_in(valid_in),
    .valid_out(valid_out)
);

comparator comp_inst(
    .cpu_tag(tag),
    .stored_tag(stored_tag),
    .valid(valid_out),
    .hit(tag_match_valid)
);

assign hit = cs && !we && tag_match_valid;
assign data_out = hit ? data_sram_out : 4'b0000;

endmodule
