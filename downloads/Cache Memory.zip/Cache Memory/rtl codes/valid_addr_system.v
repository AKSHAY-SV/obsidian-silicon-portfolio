`timescale 1ns / 1ps
module valid_addr_system(

    input wire clk,
    input wire wl,
    input wire cs,

    input wire [4:0] cpu_addr,

    input wire valid_in,

    output wire [2:0] tag,
    output wire valid_out

);

wire [1:0] index;

addr_split split_inst(

    .cpu_addr(cpu_addr),
    .tag(tag),
    .index(index)

);

valid_bit_array valid_inst(

    .clk(clk),
    .wl(wl),
    .cs(cs),

    .addr(index),

    .valid_in(valid_in),

    .valid_out(valid_out)

);

endmodule