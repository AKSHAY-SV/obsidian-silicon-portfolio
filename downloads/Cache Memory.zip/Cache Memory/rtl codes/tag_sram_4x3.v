`timescale 1ns / 1ps
module tag_sram_4x3(
input wire clk,
input wire cs,we,
input wire [1:0]addr,
input wire [2:0]din,
output wire [2:0]dout);
 reg [2:0]mem[0:3]; //4 rows 3 bits
 always@(posedge clk)
  if(cs)begin
   if(we)begin
    mem[addr]<=din; //same as data sram
    end
end 
assign dout=mem[addr];
endmodule
