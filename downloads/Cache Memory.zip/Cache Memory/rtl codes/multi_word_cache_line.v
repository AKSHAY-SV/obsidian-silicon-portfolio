`timescale 1ns / 1ps
module multiword_cache_line(
input wire clk,
input wire we,
input wire [1:0] word_offset,
input wire [3:0] din,
output wire [3:0] dout
);
reg [3:0] block [0:3];
always @(posedge clk) begin
if(we)
  block[word_offset] <= din;
end    
assign dout = block[word_offset];
endmodule
