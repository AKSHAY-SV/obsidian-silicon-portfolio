`timescale 1ns / 1ps
module write_back_logic(
input wire cpu_we,
input wire dirty,
output wire cache_we,
output wire mem_we
);
assign cache_we = cpu_we;
assign mem_we = cpu_we && dirty;
endmodule
