`timescale 1ns / 1ps

module cache_down(

    input wire clk,
    input wire rst,

    input wire cs,
    input wire we,

    input wire [4:0] cpu_address,
    input wire [3:0] cpu_data_in,

    output wire [3:0] cpu_data_out,
    output wire hit

);
 wire cache_we;
    wire mem_we;

    wire [3:0] cache_data_out;
    wire [3:0] main_mem_data_out;

    wire dirty_out;

    wire [2:0] fsm_state;
cache_top cache_inst(

        .clk(clk),
        .cs(cs),
        .we(cache_we),

        .cpu_address(cpu_address),

        .data_in(cpu_data_in),

        .valid_in(1'b1),

        .data_out(cache_data_out),

        .hit(hit)

    );
 main_memory main_mem_inst(

        .clk(clk),

        .we(mem_we),

        .addr(cpu_address[3:0]),

        .din(cpu_data_in),

        .dout(main_mem_data_out)

    );
dirty_bit_array dirty_inst(

        .clk(clk),

        .we(cache_we),

        .addr(cpu_address[1:0]),

        .dirty_in(we),

        .dirty_out(dirty_out)

    );
 cache_controller controller_inst(

        .clk(clk),

        .rst(rst),

        .hit(hit),

        .cache_we(cache_we),

        .mem_we(mem_we),

        .state(fsm_state)

    );
reg [3:0] cpu_data_reg;

always @(posedge clk) begin

    if(hit)

        cpu_data_reg <= cache_data_out;

    else

        cpu_data_reg <= main_mem_data_out;

end

assign cpu_data_out = cpu_data_reg;
endmodule
