`timescale 1ns / 1ps //Same as sram but without chip select
module main_memory(
input wire clk,
input wire we,
input wire [3:0] addr,
input wire [3:0] din,
output wire [3:0] dout
);
reg [3:0] mem [0:15];
integer i;

initial begin

    for(i = 0; i < 16; i = i + 1)

        mem[i] = 4'b0000;

end
always @(posedge clk) begin 
if(we)
mem[addr] <= din;
end
assign dout = mem[addr];
endmodule
