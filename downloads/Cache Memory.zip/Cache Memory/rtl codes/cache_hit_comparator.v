`timescale 1ns / 1ps

module comparator(

    input wire [2:0] cpu_tag,
    input wire [2:0] stored_tag,
    input wire valid,

    output reg hit

);

    always @(*) begin

        if((cpu_tag == stored_tag) && valid)

            hit = 1'b1;

        else

            hit = 1'b0;

    end

endmodule
