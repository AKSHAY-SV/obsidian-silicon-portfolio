`timescale 1ns / 1ps
module replacement_logic(
input wire clk,
input wire miss,
output reg replace_line
);
always @(posedge clk) begin
if(miss)
  replace_line <= ~replace_line;
end
endmodule