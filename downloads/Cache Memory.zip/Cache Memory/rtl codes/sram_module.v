`timescale 1ns / 1ps
module sram_module(
input wire clk,
input wire cs,we,    //cs(chip select) , we(write enable, works the same way as write line)
input wire [1:0]addr,// address
input wire [3:0]din, //data_in
output wire [3:0]dout //data_out
);
reg [3:0]mem[0:3];
always@(posedge clk)begin
if(cs)begin
 if(we)begin
  mem[addr]<=din; //when wl is 1 the value of d_in gets stored in mem[addr]
  end
 end 
end
 assign dout = mem[addr];
endmodule
