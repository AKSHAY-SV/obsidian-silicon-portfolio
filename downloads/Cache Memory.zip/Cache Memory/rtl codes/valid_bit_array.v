`timescale 1ns / 1ps
module valid_bit_array(
input wire clk,
input wire wl,cs,
input wire [1:0]addr,
input wire valid_in,
output wire valid_out);
  reg valid_mem[0:3];
integer i;

initial begin

    for(i = 0; i < 4; i = i + 1)

        valid_mem[i] = 0;

end
always@(posedge clk)begin   
   if(cs)begin
    if(wl)begin
      valid_mem[addr]<=valid_in;
     end 
    end
    end
   assign valid_out=valid_mem[addr];
endmodule