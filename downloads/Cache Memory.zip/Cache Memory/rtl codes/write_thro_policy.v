`timescale 1ns / 1ps

module write_through_logic(
input wire cpu_we,
output wire cache_we,
output wire mem_we
);
    assign cache_we = cpu_we;
    assign mem_we   = cpu_we;

endmodule
